# vomit

if you're like me and prefer using llms the traditional way (copy pasting into your llm interface) rather than through cursor or whatnot, this tool is for you.

you can use this to dump your entire filesystem into a single .txt file 

## installation
if you're on mac: 
```bash
brew tap evapilotno17/vomit
brew install vomit
vomit --help
```
if you're on windows: 
```bash
kys
```

## usage

the `--ignore` flag is optional. 

```bash
vomit --ignore .vomitignore
```
